<?php
// Helper functions go here.
